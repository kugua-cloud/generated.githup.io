import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { 
  MessageSquare, 
  Image as ImageIcon, 
  Search, 
  Mic, 
  Send, 
  Loader2, 
  Plus, 
  Sparkles,
  ExternalLink,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

// --- Constants & Types ---
const MODELS = {
  text: 'gemini-3-flash-preview',
  image: 'gemini-2.5-flash-image',
  search: 'gemini-3-pro-preview'
};

type Tab = 'chat' | 'image' | 'search';

// --- App Component ---
const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen w-full overflow-hidden">
      {/* Mobile Toggle */}
      <button 
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-zinc-800 rounded-md"
        onClick={() => setSidebarOpen(!isSidebarOpen)}
      >
        {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <div className={`${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 fixed lg:static z-40 w-64 h-full glass border-r border-zinc-800 flex flex-col p-4`}>
        <div className="flex items-center gap-2 mb-10 px-2 mt-4 lg:mt-0">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Sparkles size={20} className="text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">Gemini Lab</h1>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarItem 
            icon={<MessageSquare size={18} />} 
            label="智能对话" 
            active={activeTab === 'chat'} 
            onClick={() => {setActiveTab('chat'); if(window.innerWidth < 1024) setSidebarOpen(false);}} 
          />
          <SidebarItem 
            icon={<ImageIcon size={18} />} 
            label="图像生成" 
            active={activeTab === 'image'} 
            onClick={() => {setActiveTab('image'); if(window.innerWidth < 1024) setSidebarOpen(false);}} 
          />
          <SidebarItem 
            icon={<Search size={18} />} 
            label="联网搜索" 
            active={activeTab === 'search'} 
            onClick={() => {setActiveTab('search'); if(window.innerWidth < 1024) setSidebarOpen(false);}} 
          />
        </nav>

        <div className="p-4 mt-auto glass rounded-xl border border-zinc-800">
          <p className="text-xs text-zinc-500 mb-2 font-medium">API 状态</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
            <span className="text-sm font-semibold">Gemini 3.0 Ready</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#0c0c0e]">
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-4xl mx-auto h-full">
            {activeTab === 'chat' && <ChatModule />}
            {activeTab === 'image' && <ImageModule />}
            {activeTab === 'search' && <SearchModule />}
          </div>
        </div>
      </main>
    </div>
  );
};

// --- Sub-modules ---

const SidebarItem: React.FC<{ icon: React.ReactNode, label: string, active: boolean, onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${active ? 'bg-zinc-800 text-white shadow-lg' : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200'}`}
  >
    {icon}
    <span className="font-medium">{label}</span>
    {active && <ChevronRight size={14} className="ml-auto opacity-50" />}
  </button>
);

const ChatModule: React.FC = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: string }[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const chat = ai.chats.create({ model: MODELS.text });
      const streamResponse = await chat.sendMessageStream({ message: userMsg });

      let fullText = '';
      setMessages(prev => [...prev, { role: 'ai', content: '' }]);

      for await (const chunk of streamResponse) {
        const textChunk = (chunk as GenerateContentResponse).text;
        fullText += textChunk;
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1].content = fullText;
          return updated;
        });
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'ai', content: '抱歉，我遇到了点问题。请检查网络或 API Key 状态。' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 space-y-6 pb-24">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-60 mt-20 animate__animated animate__fadeIn">
            <div className="p-4 bg-zinc-900 rounded-full mb-4">
              <MessageSquare size={48} className="text-blue-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Gemini 极速对话</h2>
            <p className="max-w-sm">基于 Gemini 3.0 Flash，低延迟响应，支持各种创意写作与逻辑分析。</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate__animated animate__fadeInUp`}>
            <div className={`max-w-[85%] rounded-2xl px-4 py-3 ${m.role === 'user' ? 'bg-blue-600 text-white' : 'glass border-zinc-800 text-zinc-200'}`}>
              <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
            </div>
          </div>
        ))}
        <div ref={scrollRef} />
      </div>

      <div className="fixed bottom-6 left-0 right-0 px-4 md:left-auto md:right-auto md:w-full md:max-w-4xl">
        <div className="relative group">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="问问 Gemini..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-4 pl-6 pr-14 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all placeholder:text-zinc-600 shadow-2xl"
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="absolute right-3 top-3 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-colors disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
};

const ImageModule: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!prompt || loading) return;
    setLoading(true);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const response = await ai.models.generateContent({
        model: MODELS.image,
        contents: { parts: [{ text: prompt }] },
        config: {
          imageConfig: { aspectRatio: aspectRatio as any }
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setResult(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate__animated animate__fadeIn">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold mb-4">文字瞬间变画卷</h2>
        <p className="text-zinc-400">Gemini 2.5 Flash Image 驱动，理解复杂指令</p>
      </div>

      <div className="glass rounded-3xl p-6 border-zinc-800 space-y-6">
        <div>
          <label className="block text-sm font-medium text-zinc-500 mb-2">描述你的画面</label>
          <textarea 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 h-24 focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all resize-none"
            placeholder="例如: 一个赛博朋克风格的未来猫咪，站在霓虹闪烁的摩天大楼顶端，4k, 高细节..."
          />
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex gap-2">
            {['1:1', '16:9', '9:16', '3:4', '4:3'].map(ratio => (
              <button 
                key={ratio}
                onClick={() => setAspectRatio(ratio)}
                className={`px-3 py-1.5 rounded-lg text-sm border transition-all ${aspectRatio === ratio ? 'bg-purple-600 border-purple-500 text-white' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600'}`}
              >
                {ratio}
              </button>
            ))}
          </div>
          <button 
            onClick={generate}
            disabled={loading}
            className="ml-auto flex items-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-purple-900/20 transition-all active:scale-95 disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <Sparkles size={20} />}
            {loading ? '生成中...' : '开始生成'}
          </button>
        </div>
      </div>

      <div className="min-h-[400px] flex items-center justify-center glass rounded-3xl border-dashed border-2 border-zinc-800 overflow-hidden">
        {loading ? (
          <div className="text-center space-y-4">
            <Loader2 className="animate-spin text-purple-500 mx-auto" size={40} />
            <p className="text-zinc-500 animate-pulse">正在构思奇妙的艺术作品...</p>
          </div>
        ) : result ? (
          <img src={result} alt="Generated" className="w-full h-full object-contain animate__animated animate__zoomIn" />
        ) : (
          <div className="text-center p-8">
            <ImageIcon size={64} className="text-zinc-800 mx-auto mb-4" />
            <p className="text-zinc-600">生成的图像将出现在这里</p>
          </div>
        )}
      </div>
    </div>
  );
};

const SearchModule: React.FC = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<{ text: string, sources: any[] } | null>(null);

  const handleSearch = async () => {
    if (!query || loading) return;
    setLoading(true);
    setResponse(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const result = await ai.models.generateContent({
        model: MODELS.search,
        contents: query,
        config: {
          tools: [{ googleSearch: {} }]
        }
      });

      const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sources = chunks.filter((c: any) => c.web).map((c: any) => c.web);

      setResponse({
        text: result.text,
        sources: sources
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate__animated animate__fadeIn">
      <div className="flex flex-col items-center mb-10">
        <div className="w-16 h-16 bg-zinc-900 rounded-3xl flex items-center justify-center mb-6">
          <Search size={32} className="text-green-500" />
        </div>
        <h2 className="text-3xl font-bold">联网增强搜索</h2>
        <p className="text-zinc-400 mt-2">结合 Google 搜索，为您提供带来源引用的准确答案</p>
      </div>

      <div className="relative">
        <input 
          type="text" 
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-5 pl-14 pr-6 focus:outline-none focus:ring-2 focus:ring-green-500/50 transition-all placeholder:text-zinc-600"
          placeholder="搜索任何实时信息，例如：2024年全球科技趋势是什么？"
        />
        <Search className="absolute left-5 top-5.5 text-zinc-500" size={24} />
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 space-y-4">
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
            <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce"></div>
          </div>
          <p className="text-sm text-zinc-500">正在搜索全球互联网...</p>
        </div>
      )}

      {response && (
        <div className="space-y-6 animate__animated animate__fadeIn">
          <div className="glass rounded-3xl p-6 border-zinc-800">
            <p className="text-zinc-200 leading-relaxed whitespace-pre-wrap">{response.text}</p>
          </div>
          
          {response.sources.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-zinc-500 px-2 flex items-center gap-2">
                <ExternalLink size={14} /> 来源引用
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {response.sources.map((src, i) => (
                  <a 
                    key={i} 
                    href={src.uri} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 glass border-zinc-800 rounded-xl hover:bg-zinc-800/50 transition-colors group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center text-xs font-bold text-green-500 group-hover:bg-green-500 group-hover:text-white transition-colors">
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate text-zinc-200">{src.title || '网页来源'}</p>
                      <p className="text-xs text-zinc-500 truncate">{src.uri}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// --- Rendering ---
const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<App />);
}
